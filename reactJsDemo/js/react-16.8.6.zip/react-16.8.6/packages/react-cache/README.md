# react-cache

A basic cache for React applications. It also serves as a reference for more
advanced caching implementations.

This package is meant to be used alongside yet-to-be-released, experimental
React features. It's unlikely to be useful in any other context.

**Do not use in a real application.** We're publishing this early for
demonstration purposes.

**Use it at your own risk.**

# No, Really, It Is Unstable

The API ~~may~~ will change wildly between versions.
